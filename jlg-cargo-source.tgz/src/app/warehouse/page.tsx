import { redirect } from "next/navigation";

export default function WarehousePage() {
  redirect("/dashboard");
}
